package com.example.whosthere

data class User(val uid: String="", val email: String="", val friends: ArrayList<String> =ArrayList(), val lat: Double=0.0,val long:Double=0.0, val username:String="", val distance:String="")

