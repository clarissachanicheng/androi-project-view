package com.example.whosthere

class Friend (uid: String="", val lastmeet_lat: Double=0.0,val lastmeet_long:Double=0.0,  val lastseen_time:String="", val username:String="")